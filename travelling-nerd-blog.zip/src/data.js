const blogPosts = [
  {
    id: 1,
    title: "Exploring Ancient Ruins",
    description: "Unveiling the mysteries of civilizations past.",
    image: "images.jpg",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  {
    id: 2,
    title: "A Journey Through the Amazon Rainforest",
    description: "Encountering exotic wildlife and lush landscapes.",
    image: "images1.jpg",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  {
    id: 3,
    title: "Island Paradise: Basking in the Maldives",
    description: "Relaxing on pristine beaches and crystal-clear waters.",
    image: "images2.jpg",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  {
    id: 4,
    title: "Culinary Adventures in Italy",
    description: "Savoring authentic pasta, pizza, and gelato.",
    image: "images3.jpg",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  {
    id: 5,
    title: "Chasing the Northern Lights in Iceland",
    description: "Witnessing the breathtaking aurora borealis.",
    image: "images4.jpg",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
  },
  // Add more blog posts here
];

export default blogPosts;
