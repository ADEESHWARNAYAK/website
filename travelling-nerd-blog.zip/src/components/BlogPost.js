import React from "react";

const BlogPost = ({ post, onClick }) => {
  const imagePath = require(`../images/${post.image}`);
  console.log("Image Path:", imagePath);
  return (
    <div className="blog-post" onClick={() => onClick(post.id)}>
      <img src={imagePath} alt={post.title} />
      <h3>{post.title}</h3>
      <p>{post.description}</p>
    </div>
  );
};

export default BlogPost;
