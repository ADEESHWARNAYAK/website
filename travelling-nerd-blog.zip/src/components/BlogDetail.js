import React from "react";
// import Image from "../images/images.jpg";

const BlogDetail = ({ post }) => {
  const imagePath = require(`../images/${post.image}`);
  console.log("Image Path:", imagePath);
  return (
    <div
      className="blog-detail"
      style={{
        border: "1px solid #ddd",
        padding: "20px",
        maxWidth: "100%",
        margin: "0 auto",
        boxSizing: "border-box"
      }}
    >
      <img
        src={imagePath}
        alt={post.title}
        style={{
          maxWidth: "100vw", // Set maximum width based on viewport width
          maxHeight: "50vh", // Set maximum height based on 80% of viewport height
          height: "auto",
          marginBottom: "20px"
        }}
      />
      <h2
        style={{
          fontSize: "28px",
          marginBottom: "10px"
        }}
      >
        {post.title}
      </h2>
      <p
        style={{
          fontSize: "16px",
          lineHeight: "1.6"
        }}
      >
        {post.content}
      </p>
    </div>
  );
};

export default BlogDetail;
