import React from "react";
import logoImage from "../images/logo.jpg"; // Adjust the path to match your actual image location

const Header = () => {
  return (
    <header className="header">
      <div className="logo-container">
        <img src={logoImage} alt="Traveling Nerd Logo" className="logo" />
      </div>
      <h1 className="companyName">Traveling Nerd</h1>
      <div></div>
    </header>
  );
};

export default Header;
