import React from "react";

const Footer = () => {
  return <footer className="footer">Contact: example@example.com</footer>;
};

export default Footer;
