import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import { Outlet } from "react-router-dom";

const Layout = () => {
  return (
    <div className="layout">
      <Header />
      <main className="content">
        <Outlet /> {/* Render child route content */}
      </main>
      <Footer />
    </div>
  );
};

export default Layout;
