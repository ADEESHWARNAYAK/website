import React from "react";
import { useParams } from "react-router-dom";
import BlogDetail from "../components/BlogDetail";
import blogPosts from "../data";
import "./postpage.css";

const PostPage = () => {
  const { id } = useParams();
  const postId = parseInt(id);
  const post = blogPosts.find((post) => post.id === postId);

  if (!post) {
    return <div>Post not found</div>;
  }

  return (
    <div className="post-page">
      <BlogDetail post={post} />
    </div>
  );
};

export default PostPage;
