import React from "react";
import {useNavigate} from "react-router-dom";
import BlogPost from "../components/BlogPost";
import blogPosts from "../data";
import './homepage.css'

const HomePage = () => {
  console.log("HomePage is rendered"); // Debug message
  const navigate = useNavigate();

  const handlePostClick = (postId) => {
    navigate(`/post/${postId}`);
  };

  return (
    <div className="home-page">
      <div className="intro">
        <h2>Welcome to Traveling Nerd</h2>
        <p>Explore exciting travel stories and experiences from around the world.</p>
      </div>
      <div className="blog-list">
        {blogPosts.map((post) => (
          <BlogPost key={post.id} post={post} onClick={handlePostClick} />
        ))}
      </div>
    </div>
  );
};

export default HomePage;
